
<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="I was under the impression that a yellow question mark signifies a missing EDS file. However, despite seeing one in the Properties, I am unable to locate a specific EDS file for download for this module. The Rockwell Automation website does not have any available EDS files for download.">
    <meta name="keywords" content="eds files, rslinx, missing eds files, rockwell automation, download eds files, yellow question mark, locate eds file, rockwell eds files, elusive eds files, eds file download, eds files">
    <meta name="author" content="oxmaint">
    
    <link rel="canonical" href="https://community.oxmaint.com/discussion-forum/where-to-find-missing-eds-files-for-rslinx">
    <title>Where to Find Missing EDS Files for RSLinx? | Oxmaint Community</title>
    <link rel="shortcut icon" href="./../assets/img/favicon.png" />
    <link rel="stylesheet" href="./../assets/css/plugins.css" />
    <link rel="stylesheet" href="./../assets/css/style.css" />
    <link rel="stylesheet" href="./../assets/css/colors/purple.css" />
    
    <!-- og or twitter tags -->
    <meta property="og:type" content="article">
    <meta property="og:title" content="Where to Find Missing EDS Files for RSLinx? | Oxmaint Community">
    <meta property="og:description" content="I was under the impression that a yellow question mark signifies a missing EDS file. However, despite seeing one in the Properties, I am unable to locate a specific EDS file for download for this module. The Rockwell Automation website does not have any available EDS files for download.">
    <meta property="og:url" content="https://community.oxmaint.com/discussion-forum/where-to-find-missing-eds-files-for-rslinx">
    <meta property="og:site_name" content="Oxmaint">
    <meta property="og:image" content="https://community.oxmaint.com/assets/img/favicon.png">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Where to Find Missing EDS Files for RSLinx? | Oxmaint Community">
    <meta name="twitter:description" content="I was under the impression that a yellow question mark signifies a missing EDS file. However, despite seeing one in the Properties, I am unable to locate a specific EDS file for download for this module. The Rockwell Automation website does not have any available EDS files for download.">
    <meta name="twitter:image" content="https://community.oxmaint.com/assets/img/favicon.png">

    <!-- Global site tag (gtag.js) - Google Analytics -->
    <script async src="https://www.googletagmanager.com/gtag/js?id=G-Y6M0T9NLP4"></script>
    <script>
        window.dataLayer = window.dataLayer || [];
        function gtag() { dataLayer.push(arguments); }
        gtag('js', new Date());
        gtag('config', 'G-Y6M0T9NLP4');
    </script>

    <!-- Structured Data (Schema.org) -->
    <script type="application/ld+json">
    {
      "@context": "https://schema.org",
      "@type": "Article",
      "mainEntityOfPage": {
        "@type": "WebPage",
        "@id": "https://community.oxmaint.com/discussion-forum/where-to-find-missing-eds-files-for-rslinx"
      },
      "headline": "Where to Find Missing EDS Files for RSLinx?",
      "description": "I was under the impression that a yellow question mark signifies a missing EDS file. However, despite seeing one in the Properties, I am unable to locate a specific EDS file for download for this module. The Rockwell Automation website does not have any available EDS files for download.",
      "author": {
        "@type": "Person",
        "name": "TheWaterboy"
      },
      "publisher": {
        "@type": "Organization",
        "name": "Oxmaint",
        "logo": {
          "@type": "ImageObject",
          "url": "https://community.oxmaint.com/assets/img/favicon.png"
        }
      },
      "datePublished": "2024-10-03",
      "image": "https://community.oxmaint.com/assets/img/favicon.png"
    }
    </script>

<link href="https://assets.calendly.com/assets/external/widget.css" rel="stylesheet">
<script src="https://assets.calendly.com/assets/external/widget.js" type="text/javascript" defer></script>
<link rel="stylesheet" href="./../assets/css/home.css"/>
</head>
<body>
    <div class="content-wrapper bg-gray">
        <?php include "../include/header.php" ?>
        <!-- /header -->
        <div class="container my-5">
            

            <div class="bg-primary card p-4 mb-4">
                <h1 class="text-white">Where to Find Missing EDS Files for RSLinx?</h1>
                <div class="d-flex justify-content-between">
                    <ul class="post-meta text-white fs-15 mb-4">
                        <li class="post-date"><i class="uil uil-calendar-alt"></i><span>03-10-2024</span></li>
                        <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
                        <li class="post-comments"><i class="uil uil-comment-alt-dots"></i><span>15 comments</span></li>
                        <li class="post-seen"><i class="uil uil-eye"></i><span id="counter">577</span></li>
                        <li class="post-like"><i class="uil uil-thumbs-up" id="likeButton"></i><span id="likeCount">165</span></li>
                    </ul>
                </div>
                <div class="card p-4">
                    <h3>Question:</h3>
                    <p>I was under the impression that a yellow question mark signifies a missing EDS file. However, despite seeing one in the Properties, I am unable to locate a specific EDS file for download for this module. The Rockwell Automation website does not have any available EDS files for download. Where can I find these elusive files?</p>
                </div>
            </div>

            <div class="row custom-row">
                <div class="col-lg-9 mx-auto mb-5">
                    <div>
                        <div class="p-4">
                            <h3 class="text-primary">Top Replies</h3>
                            
        <div class="bg-white p-3 rounded mb-3">
            <p>To easily upload Eds from the module, simply right click on the module interface. Many modules offer this convenient feature for seamless integration.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>04-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>robertmee</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>Have you downloaded the Aspect-Oriented Programming (AOP) tool yet?</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>05-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>robertmee</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>I was surprised to find that the right-click option I was looking for is not available. Does Linx have the EDS file needed for AOP?</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>06-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>TheWaterboy noted that the right-click option does not seem to be available as anticipated. This pertains to Linx, and I am curious if AOP has the EDS file. Click to expand for more information. Yup.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>06-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>robertmee</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>In hindsight, I should have been more aware of that, but I let my contentment cloud my judgment, assuming everything was in place.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>06-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
                        </div>
                        <div class="p-4">
    <h3 class="text-primary">
        <a href="#" class="toggle-more-replies" style="text-decoration: underline; color: #1a73e8; cursor: pointer;">More Replies →</a>
    </h3>
    <div class="more-replies-content" style="display: none;">
                            
        <div class="bg-white p-3 rounded mb-3">
            <p>It is imperative to note that not all devices come with an embedded EDS file, despite the CIP specification clearly indicating its necessity. By obtaining the AOP, you will also acquire the essential EDS files for the modules, satisfying linx requirements. It is worth mentioning that the base modules typically have EDS files automatically installed by Studio 5000. If you are unsure about the authenticity of your modules, it may be wise to consider their source.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>06-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>tlf30</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>tlf30 pointed out that while the CIP spec mandates the presence of an embedded EDS file in all devices, not all devices come with one. By obtaining the AOP, you can ensure access to the EDS files for the modules, which will make RSLinx function properly. It's worth noting that the base modules typically have EDS files automatically installed by Studio 5000. If you're experiencing issues, it's important to verify the authenticity of your modules and the source from where they were obtained. This brings up an interesting point, as the modules in question were part of a packaged system. While Logix on the same machine is functioning well in terms of seeing and configuring the modules, RSLinx is encountering difficulties.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>07-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>It is possible that the computer has the EDS file for Series A, but not for Series B. The duration of time that Series B has been available is unclear. However, updating the Add-On Profile (AOP) should fix the issue in RSLinx.OG, resolving any communication errors.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>07-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>Operaghost</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>What sets apart the 2 different AOP options - a web-based interface versus an integrated one? And why is opting for a web-based interface a beneficial choice?</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>I have successfully installed both AOP's, but the Linx query still persists. I will now proceed to investigate further at RA.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>An important aspect to consider is that navigating the internet can be overwhelming due to its novelty, requiring more effort and time to access information. It's often believed that more is better, but it's crucial to seek advice from reliable sources like RA. If counterfeit parts are identified (even high-quality replicas), RA may nullify the system warranty. However, they excel at detecting issues. A red flag for potential counterfeits is the inability to locate the EDS file through the vendor Id, product code, and version combination. If the file is not found, it could suggest an invalid product code or version, indicating a counterfeit module. Hoping it's just a glitch from Linx and not a counterfeit issue.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>tlf30</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>I'm curious if the download option isn't appearing due to an outdated or incorrect setting being in place. If there's already a setting enabled, there's no need to display the download option.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>TheWaterboy raised a question about the unavailability of the download option due to a possibly outdated or incorrect setting in place. If you are utilizing a pre-configured linx driver with previously installed modules in the rack, there may be a residual identifier causing the module to not be physically visible now. To overcome this issue, consider creating a new Ethernet/IP driver, accessing the rack, and exploring what it detects.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>robertmee</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>Yes, it appears that a new feature has been added, suggesting a possible correlation between the AOP in Logix and the EDS in Linx. This connection is worth exploring further for enhanced system integration and performance optimization.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>TheWaterboy</span></li>
            </ul>
        </div>
        
        <div class="bg-white p-3 rounded mb-3">
            <p>TheWaterboy noted that a new addition indicates a connection between the AOP in Logix and the EDS in Linx, suggesting potential shared EDS files across various Rockwell Automation applications. This integration promises to bring about new EDS files that can enhance operational efficiency within industrial settings.</p>
            <ul class="post-meta mb-0">
                <li class="post-date"><i class="uil uil-calendar-alt"></i><span>08-10-2024</span></li>
                <li class="post-author"><i class="uil uil-user"></i><span>tlf30</span></li>
            </ul>
        </div>
        
                        </div>
                    <div class="no-replies-message" style="display: none; color: gray;">
        No More Replies.
    </div>
        
                        </div>
                    </div>
                </div>
                <div class="col-lg-3 outer-container">
        <!-- Related Topics -->
    <?php include "./related-topic.php" ?>
    </div>
            </div>
             <!-- cta button -->
        <?php include "./cta.php" ?>

            <!-- FAQ Section -->
            <div class='my-5'><h3 class='faq-title text-primary mb-4'>Frequently Asked Questions (FAQ)</h3>
<div class='faq-item bg-light p-4 rounded shadow-sm mb-3'>
<h4 class='text-dark'>FAQ: 1.  What does a yellow question mark in RSLinx properties indicate?</h4>
<p class='text-muted'><strong>Answer:</strong> Answer: A yellow question mark in RSLinx properties typically signifies a missing EDS file for the mentioned module.</p>
</div>
<div class='faq-item bg-light p-4 rounded shadow-sm mb-3'>
<h4 class='text-dark'>FAQ: 2.  Where can I download missing EDS files for Rockwell Automation products?</h4>
<p class='text-muted'><strong>Answer:</strong> Answer: You can find EDS files for Rockwell Automation products on the Rockwell Automation website or through the DeviceNet website.</p>
</div>
<div class='faq-item bg-light p-4 rounded shadow-sm mb-3'>
<h4 class='text-dark'>FAQ: 3.  What should I do if I cannot locate a specific EDS file for download for a module?</h4>
<p class='text-muted'><strong>Answer:</strong> Answer: If you are unable to find the specific EDS file for download on the Rockwell Automation website, you may consider reaching out to Rockwell Automation technical support for assistance.</p>
</div>
</div>
        </div>
        <?php include "./footer-banner.php" ?>

        <!-- /footer -->
        <?php include "../include/footer.php" ?>

        <script src="like-view-counter.js"></script>
    </div>
<script>
document.addEventListener("DOMContentLoaded", () => {
    function initializeToggleFunctionality() {
        const toggleLink = document.querySelector(".toggle-more-replies");
        const moreRepliesContent = document.querySelector(".more-replies-content");
        const noRepliesMessage = document.querySelector(".no-replies-message");

        if (!toggleLink || !moreRepliesContent || !noRepliesMessage) {
            console.error("Required elements not found. Ensure the correct class names are used.");
            console.log({
                toggleLink,
                moreRepliesContent,
                noRepliesMessage,
            });
            return;
        }

        const hasReplies = Array.from(moreRepliesContent.children).some(
            (child) => child.nodeType === Node.ELEMENT_NODE
        );

        if (hasReplies) {
            noRepliesMessage.style.display = "none";
        } else {
            noRepliesMessage.style.display = "block";
            toggleLink.style.display = "none";
            return;
        }

        toggleLink.addEventListener("click", (event) => {
            event.preventDefault();
            const isHidden = getComputedStyle(moreRepliesContent).display === "none";
            moreRepliesContent.style.display = isHidden ? "block" : "none";
            toggleLink.textContent = isHidden ? "Hide More Replies" : "More Replies →";
        });
    }

    initializeToggleFunctionality();

    const observer = new MutationObserver(() => {
        const toggleLink = document.querySelector(".toggle-more-replies");
        const moreRepliesContent = document.querySelector(".more-replies-content");

        if (toggleLink && moreRepliesContent) {
            initializeToggleFunctionality();
            observer.disconnect();
        }
    });

    observer.observe(document.body, { childList: true, subtree: true });
});
</script>
</body>
</html>
